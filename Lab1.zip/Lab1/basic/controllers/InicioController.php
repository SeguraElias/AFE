<?php

namespace app\controllers;

use app\models\InicioForm;
use Yii;
use yii\filters\AccessControl;
use yii\web\Response;
use yii\filters\VerbFilter;
use yii\web\Controller;

class InicioController extends Controller {
    public function actionIndex(){
        $mensaje = 'Yes, it is';
        $h2 = 'UNIVO';
        $dateTime = new \DateTime();

        return $this->rendes(
            'index',
            [
                'mensaje' => $mensaje,
                'h2' => $h2,
                'dateTime' => $dateTime,
            ]
        );
    }

    public function actionOperaciones(){
        $model = new inicioForm();

        if ($model->load(Yii::$app->request->post()) && $model->validate()) {
            if ($model->opcion[0] == 0){
                $resultado = $model->valor_a + $model->valor_b;
                $respuesta = "El resultado de ". $model->valor_a . " + ".$model->valor_b." es: ". $resultado;
                return $this->render('operaciones', ['respuesta' => $respuesta, 'model' => $model]);
            }
            else if($model->opcion[0] == 1){
                $resultado = $model->valor_a - $model->valor_b;
                $respuesta = "El resultado de ". $model->valor_a . " - ".$model->valor_b." es: ". $resultado;
                return $this->render('operaciones', ['respuesta' => $respuesta, 'model' => $model]);
            }
            else if($model->opcion[0] == 2){
                $resultado = $model->valor_a * $model->valor_b;
                $respuesta = "El resultado de ". $model->valor_a . " x ".$model->valor_b." es: ". $resultado;
                return $this->render('operaciones', ['respuesta' => $respuesta, 'model' => $model]);
            }
            else if($model->opcion[0] == 3){
                $resultado = $model->valor_a / $model->valor_b;
                $respuesta = "El resultado de ". $model->valor_a . " / ".$model->valor_b." es: ". $resultado;
                return $this->render('operaciones', ['respuesta' => $respuesta, 'model' => $model]);
            }
        }

        return $this->render('operaciones', ['model' => $model]);
    }


}


?>
