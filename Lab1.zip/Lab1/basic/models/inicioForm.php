<?php

namespace app\models;

use Yii;
use yii\base\Model;

class InicioForm extends Model 
{
    public $valor_a;
    public $valor_b;
    public $opcion;

    public function rules(){
        return [
            [['valor_a', 'valor_b', 'opcion'], 'required'],
            [['valor_a', 'valor_b'], 'number'],
        ];
    }
}

?>